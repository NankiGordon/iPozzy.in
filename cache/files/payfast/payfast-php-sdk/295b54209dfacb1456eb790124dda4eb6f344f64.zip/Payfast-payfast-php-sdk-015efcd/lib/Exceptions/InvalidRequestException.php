<?php

namespace PayFast\Exceptions;

use Exception;

class InvalidRequestException extends Exception
{
}
