<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>TEST SDK</title>
</head>
<body>

<div class='test-panel'>
    <a href="./custom">Custom</a><br>
    <a href="./credit-card-transaction-query">Credit Card transaction Query</a><br>
    <a href="./onsite">Onsite</a><br>
    <a href="./recurring">Recurring</a><br>
    <a href="./refunds">Refunds</a><br>
    <a href="./transaction-history">Transaction Query</a><br>
    <a href="./update-card">Update Card</a><br>
</div>

</body>
</html>
